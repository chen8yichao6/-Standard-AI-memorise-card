# -*- coding: utf-8 -*-
"""v9 -> v10 两项硬指标复核：墨滴核内对比度 / 湿边 / 暗房颗粒。"""
from PIL import Image
import numpy as np

def load(p):
    return np.asarray(Image.open(p).convert('L'), dtype=np.float32)

CY, CX = 816, 1100          # 墨滴圆心（device px，布局未变所以不变）
NA = 72
TH = np.linspace(0, 2 * np.pi, NA, endpoint=False)
RADII = [0, 10, 20, 30, 40, 45, 48, 50, 52, 55, 58, 62, 66, 70, 74, 78, 82, 86, 90]

def profile(im):
    out = []
    for rc in RADII:
        r = rc * 2
        xs = (CX + np.cos(TH) * r).round().astype(int)
        ys = (CY + np.sin(TH) * r).round().astype(int)
        out.append(im[ys, xs].mean())
    return out

def core(im, r_css=45):
    yy, xx = np.mgrid[0:im.shape[0], 0:im.shape[1]]
    pr = np.hypot(xx - CX, yy - CY)
    v = im[pr < r_css * 2]
    return v.std(), np.percentile(v, 5), np.percentile(v, 50), np.percentile(v, 95)

def grain(im):
    b = im[1298:1330, 740:1460]                 # 暗房干净空带
    d = np.abs(np.diff(b, axis=1))
    return b.std(), b.min(), b.max(), np.median(d)

for tag, p in (('v9 ', '.workbuddy/shot-v9.png'), ('v10', '.workbuddy/shot-v10.png')):
    im = load(p)
    st, p5, p50, p95 = core(im)
    gs, gmin, gmax, gmed = grain(im)
    print('=== %s ===' % tag)
    print('  核内 r<45css   std=%5.2f   分位 5/50/95 = %.0f / %.0f / %.0f' % (st, p5, p50, p95))
    print('  暗房空带       std=%5.2f   min=%.0f max=%.0f  相邻差中位=%.1f' % (gs, gmin, gmax, gmed))
    print('  径向(css:val)  ' + ' '.join('%.0f:%.0f' % (r, v) for r, v in zip(RADII, profile(im))))
