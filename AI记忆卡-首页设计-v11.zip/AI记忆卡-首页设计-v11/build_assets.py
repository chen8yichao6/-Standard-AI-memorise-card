# -*- coding: utf-8 -*-
"""步骤⑥ 素材层构建：
   assets/ink-blot.png   真墨迹 alpha 蒙版（录音键着色）
   assets/film-grain.png 中灰居中的 35mm 颗粒+划痕贴图（overlay 叠加不抬底噪）
   -> design-mockup-home.html 由 design-mockup-home.src.html 内联生成
      （mask-image 在 file:// 下会被 CORS 拦，必须内联）
"""
import base64
import re
import numpy as np
from PIL import Image, ImageFilter

SRC_INK = 'assets/A_single_drop_of_Chinese_ink___2026-10-10T14-44-54.png'
SRC_GRAIN = 'assets/Seamless_texture_scan_of_35mm__2026-10-10T14-44-59.png'
SRC_PAPER = 'assets/Macro_flatbed_scan_of_one_blan_2026-10-10T15-07-15.png'
SRC_HTML = 'design-mockup-home.src.html'
OUT_HTML = 'design-mockup-home.html'

# ---------- 1. 墨迹 -> alpha 蒙版（384px，够 2x 下 108px 显示）----------
a = np.asarray(Image.open(SRC_INK).convert('L'), dtype=np.float32)
h, w = a.shape
edge = np.concatenate([a[0:40, :].ravel(), a[-40:, :].ravel(),
                       a[:, 0:40].ravel(), a[:, -40:].ravel()])
bg, ink = float(np.median(edge)), float(np.percentile(a, 0.5))
alpha = (np.clip((bg - a) / max(bg - ink, 1.0), 0, 1) ** 0.85 * 255).astype(np.uint8)
alpha[alpha < 12] = 0
ys, xs = np.nonzero(alpha > 24)
cy, cx = (ys.min() + ys.max()) / 2.0, (xs.min() + xs.max()) / 2.0
half = max(xs.max() - xs.min(), ys.max() - ys.min()) / 2.0 * 1.16
x0, x1 = int(max(0, cx - half)), int(min(w, cx + half))
y0, y1 = int(max(0, cy - half)), int(min(h, cy + half))

# 原图是放射状溅射（在浅色纸面上读作"血渍"）。
# 三轮实测结论（对照图见 .workbuddy/c-ink-*.png）：
#   ① 单纯高斯模糊  -> 尖刺消失但糊成"毛球"，读作失焦圆点
#   ② 形态学开运算  -> 形状还在，但外圈仍拖出针状纹
#   ③ 本方案        -> 大高斯后**按等值线阈值化**取有机硬边，再轻微羽化
# 一滴墨是"边界清晰、略不规则的实体"，晕在边界**外**（交给 CSS 的 .bleed 层）。
B1, THR, B2, DB, DW, GAIN, GAM = 16, 0.38, 2.0, 34, 0.25, 1.10, 0.95
crop = Image.fromarray(alpha[y0:y1, x0:x1], 'L').resize((384, 384), Image.LANCZOS)
craw = np.asarray(crop, dtype=np.float32) / 255.0
dens = np.clip((craw - 0.05) / 0.55, 0, 1) ** 0.85
sm = np.asarray(crop.filter(ImageFilter.GaussianBlur(B1)), dtype=np.float32) / 255.0
solid = (sm > THR).astype(np.uint8) * 255                                  # 有机硬边
soft = np.asarray(Image.fromarray(solid, 'L').filter(ImageFilter.GaussianBlur(B2)),
                  dtype=np.float32) / 255.0                                # 轻羽化
ds = np.asarray(Image.fromarray((dens * 255).astype(np.uint8), 'L')
                .filter(ImageFilter.GaussianBlur(DB)), dtype=np.float32) / 255.0
f = np.clip(soft * (1.0 - DW + DW * ds) * GAIN, 0, 1) ** GAM               # 核内极轻的积墨
# 关键一步：原图是**放射溅射**，用 alpha>24 求的包围盒被细长溅射臂撑大，
# 真正的密实核只占框的 ~45% —— 于是墨滴渲染出来偏小、而 CSS 的渗晕层跑到很远，
# 读成"一圈脱离黑核的暗环"。这里按**实体自身**的包围盒重裁 + 6% 留白，
# 让墨滴稳定占满蒙版框的 ~88%，渗晕层才能贴住它。
ys2, xs2 = np.nonzero(f > 0.06)
pa = int(round(max(xs2.max() - xs2.min(), ys2.max() - ys2.min()) * 0.06))
fy0, fy1 = max(0, int(ys2.min()) - pa), min(f.shape[0], int(ys2.max()) + pa + 1)
fx0, fx1 = max(0, int(xs2.min()) - pa), min(f.shape[1], int(xs2.max()) + pa + 1)
n = max(fy1 - fy0, fx1 - fx0)
sq = np.zeros((n, n), dtype=np.float32)
oy, ox = (n - (fy1 - fy0)) // 2, (n - (fx1 - fx0)) // 2
sq[oy:oy + (fy1 - fy0), ox:ox + (fx1 - fx0)] = f[fy0:fy1, fx0:fx1]
rgba = np.zeros((384, 384, 4), dtype=np.uint8)
rgba[..., 3] = (np.asarray(Image.fromarray((sq * 255).astype(np.uint8), 'L')
                           .resize((384, 384), Image.LANCZOS), dtype=np.float32)).astype(np.uint8)
print('[ink] 墨滴占蒙版框 %.0f%%（重裁前约 45%%）' % ((ys2.max() - ys2.min()) / float(n) * 100))

# ---------- 1b. 边缘结构：让"毛边"在渲染尺度下还活着 ----------
# 病因诊断：蒙版里的有机细节是 384px 尺度的，成品渲染到 150px 要缩 2.56 倍，
# 亚像素的细节被平均掉 -> 剩下的就是一个"高斯糊过的椭圆"，也就是评审说的"匀质模糊黑圆"。
# 注意：brief 要的是"边缘是**毛的**，不是锐的"（生宣吸墨本来就洇得开），
# 所以修法不是把边磨锐，而是**把起伏做到能在 150px 下存活的尺度**。
def _rmap(rs, gat):
    """每个像素上、该角度对应的边界半径 R（含角向起伏）。
    d = R - pr 即「像素到边界的距离」，正 = 在内侧。"""
    yy, xx = np.mgrid[0:384, 0:384].astype(np.float32)
    pr = np.hypot(xx - 191.5, yy - 191.5)
    pa = np.arctan2(yy - 191.5, xx - 191.5) % (2 * np.pi)
    R = (rs * (1.0 + gat))[(pa / (2 * np.pi) * NA).astype(int) % NA]
    return R, pr

def restride(rs, gat, feather=1.6):
    """按角向调制后的半径重建蒙版（rs 为 NA 个角度上的原半径）。"""
    R, pr = _rmap(rs, gat)
    return np.clip((R - pr) / feather + 0.5, 0, 1)

def wetedge(rs, gat, wet):
    """紧贴边界内侧 wet 像素的一圈"湿边"：alpha 回满到 1.0。
    物理依据：墨在纸纤维里停住时溶质会沿边界沉积 -> **真墨斑是边缘比中心浓**。
    而此前实测的径向剖面是 19 -> 30 单调上升（中心比边缘浓），方向恰好反了 ——
    这一圈把它校正回来，同时给边界"定形"，让轮廓不再被外圈的柔晕糊掉。
    ⚠ 只准加在内侧：用 (d/0.8+1) 做门控，d < -0.8（外侧）处为 0，外侧轮廓分毫不动。
    ⚠⚠ 方向别写反：`1 - d/wet` 才是"边界最浓、往内 wet 处归零"。
        写成 `(d+wet)/wet` 会在**核内深处也饱和到 1.0**，把整颗墨拉成一块纯黑平板
        （实测核内 std 会从 5.5 掉到 0.00，墨滴变成一个没任何浓淡的色块）。
    宽度是 384px 蒙版像素，成品要缩 0.39 倍，所以 wet=9 -> 约 2.9 css px。"""
    R, pr = _rmap(rs, gat)
    d = R - pr
    return np.clip(1.0 - d / wet, 0, 1) * np.clip(d / 0.8 + 1.0, 0, 1)

def waves(lobes, amp, seed, jit=0.30):
    """多尺度 1D **值噪声**（平滑插值的随机序列）。
    ⚠ 不要用"孤立高斯波瓣求和"：波瓣之间会退化成平直刻面，成品读作"低多边形石头"；
       值噪声构造上就是 C1 连续的有机曲线，这才是"墨在纤维里走着走着偏了"的质感。"""
    r = np.random.default_rng(seed)
    kv = r.random(lobes)
    x = th / (2 * np.pi) * lobes
    i0 = np.floor(x).astype(int)
    f = x - i0
    s = f * f * (3 - 2 * f)                       # smoothstep，保证一阶连续
    return amp * (kv[i0 % lobes] * (1 - s) + kv[(i0 + 1) % lobes] * s - 0.5) * 2

def noise2d(cells, seed):
    """低频 2D 值噪声：小随机图 BICUBIC 放大 = 平滑大斑，只用来做"积墨"的浓淡。"""
    r = np.random.default_rng(seed)
    im = Image.fromarray((r.random((cells, cells)) * 255).astype(np.uint8), 'L')
    v = np.asarray(im.resize((384, 384), Image.BICUBIC), dtype=np.float32) / 255.0
    return (v - v.mean()) * 2.0

base = rgba[..., 3].astype(np.float32) / 255.0
pool = 0.30 * noise2d(5, 31) + 0.20 * noise2d(11, 32) + 0.11 * noise2d(23, 33)
# 核内"积墨"：实测 5/50/95 分位 = 16/27/37（std 6.84）—— 量程太窄，肉眼只读作"均匀黑"。
# 剂量 ×0.17 -> ×0.34、下限 0.78 -> 0.86：整体仍是黑，但内部浮出"池积/水渍"的大片浓淡。
# pool 是**低频** 2D 噪声（5/11/23 cells 放大到 384），所以是连续的斑块，不是颗粒噪点。
inner = np.clip(0.96 + pool * 0.34, 0.86, 1.0)       # 内部 alpha 0.86~1.0 -> 亮度约 14~44
WET = 9.0                                             # 湿边宽度（384 蒙版 px -> 成品约 2.9 css px）
NA = 2048
ctr = 191.5
th = np.linspace(0, 2 * np.pi, NA, endpoint=False)
rad = np.arange(0, 384, dtype=np.float32)
sx = np.clip((ctr + np.cos(th)[:, None] * rad).round().astype(int), 0, 383)
sy = np.clip((ctr + np.sin(th)[:, None] * rad).round().astype(int), 0, 383)
r0 = np.array([(np.nonzero(rw > 0.5)[0].max() if (rw > 0.5).any() else 1)
               for rw in base[sy, sx]], np.float32)
# 待机：低频"淌" + 中频"毛" —— 两者都在 150px 下有存活尺度
gidle = waves(7, 0.026, 20261011) + waves(23, 0.010, 77)
# 积墨与湿边分两步叠加：`restride*inner` 给"核内斑驳"，`wetedge` 单独给"边界一圈更浓"。
# 湿边必须用 max 兜底盖在乘积**之后** —— 直接乘进 inner 会被平均掉，等于白做。
ideal = np.clip(np.maximum(restride(r0, gidle) * inner,
                           wetedge(r0, gidle, WET)) * 1.02, 0, 1) ** 0.96
rgba[..., 3] = (ideal * 255).astype(np.uint8)
print('[ink] 待机毛边：7/23 两档值噪声 ±%.1f%% ；150px 下约 ±%.1f css px' % (
    gidle.max() * 100, r0.mean() * gidle.max() * 150 / 384))
print('[ink] 湿边：紧贴边界内侧 %.0f 蒙版 px（成品约 %.1f css px）' % (WET, WET * 150 / 384))
Image.fromarray(rgba, 'RGBA').save('assets/ink-blot.png', optimize=True, compress_level=9)

# ---------- 1c. 录音态：更强的毛刺（配合 CSS 的位移滤镜一起用）----------
gre = waves(9, 0.030, 20261012) + waves(41, 0.022, 88) + waves(97, 0.016, 4)
jaw = np.zeros((384, 384, 4), dtype=np.uint8)
jaw[..., 3] = (np.clip(np.maximum(restride(r0, gre, 1.4) * inner,
                                  wetedge(r0, gre, WET)) * 1.04, 0, 1) ** 0.96 * 255).astype(np.uint8)
Image.fromarray(jaw, 'RGBA').save('assets/ink-wave.png', optimize=True, compress_level=9)
print('[ink] 录音毛刺：9/31/97 三档值噪声 ±%.1f%% ；150px 下约 ±%.1f css px' % (
    gre.max() * 100, r0.mean() * gre.max() * 150 / 384))

# ---------- 2. 颗粒：缩到真实观感尺寸 + 镜像成无缝 + 量化 ----------
# 原始扫描裁 640px 直接铺 = 把颗粒放大了 ~6 倍（像下雪）。先降到 300px 再铺。
g = Image.open(SRC_GRAIN).convert('L').crop((0, 0, 640, 640)).resize((300, 300), Image.LANCZOS)
g = np.asarray(g, dtype=np.float32)
g2 = np.clip(128.0 + (g - float(g.mean())) * 3.4, 96, 255)
g2 = np.round((g2 - 96) / (255 - 96) * 31) * (159 / 31) + 96      # 32 级量化
# 镜像 2x2 拼成 600x600：边缘天然对齐，彻底消除 tile 接缝
tile = np.block([[g2, np.fliplr(g2)], [np.flipud(g2), np.flipud(np.fliplr(g2))]])
Image.fromarray(tile.astype(np.uint8), 'L').convert('RGB').save(
    'assets/film-grain.png', optimize=True, compress_level=9)

# ---------- 2b. 暗房专用颗粒：黑底白噪 ----------
# 病因：纸上那层用 mix-blend-mode:overlay，而 overlay 在暗底上是乘法 ——
#       2 × 0.051(底 #0D) × 0.502 ≈ 0.051，结果几乎等于原值。
#       实测暗房干净空带 std 仅 0.67、相邻像素差中位 0.0 = 纯平面。
# 处方：另导一张"黑底白噪"（中灰全部压黑，只留颗粒亮点），暗房改用 normal 混合 ——
#       底色 #0D 不被抬高，浮上来的只有噪声本身（目标成品 std 2~5）。
gq = np.asarray(Image.open(SRC_GRAIN).convert('L').crop((0, 0, 640, 640))
                .resize((300, 300), Image.LANCZOS), dtype=np.float32)
# ⚠ 不能写固定的放大系数：这张扫描图的动态范围本来就很窄，×3.2 硬放大后
#   实测 max 只有 131、且 >8 的像素只占 5.6% —— 等于一张几乎全黑、只有零星暗灰点的图。
#   改用**分位映射**把量程拉满：p72 以下压成纯黑，p99.5 映射到 255。
lo = float(np.percentile(gq, 72))                 # 只留最亮的 ~28% 当颗粒
hi = float(np.percentile(gq, 99.5))               # 用 p99.5 而不是 max，避开离群点
gd = np.clip((gq - lo) / max(hi - lo, 1e-6) * 255.0, 0, 255)
tile_d = np.block([[gd, np.fliplr(gd)], [np.flipud(gd), np.flipud(np.fliplr(gd))]])
Image.fromarray(tile_d.astype(np.uint8), 'L').save(
    'assets/film-grain-dark.png', optimize=True, compress_level=9)
print('[grain] 暗房：黑底白噪 p72=%.1f p99.5=%.1f 量程=%.1f，亮点占 %.0f%%，峰值看 %.0f%% 像素 >120'
      % (lo, hi, hi - lo, (gq > lo).mean() * 100, (gd > 120).mean() * 100))

# ---------- 3. 生宣纸面 ----------
# 高通半径要小：110px 只滤掉 >110px 的结构，剩下的 40~100px 尺度仍在 -> 读作"云斑/水渍"。
# 改 45px，只留真正的纤维起伏，滤掉一切"云"。
pi = Image.open(SRC_PAPER).convert('L').crop((0, 0, 860, 860)).resize((700, 820), Image.LANCZOS)
pi = pi.filter(ImageFilter.GaussianBlur(2.0))     # 抖掉"裂"感，留下柔软纤维
p = np.asarray(pi, dtype=np.float32)
# 振幅 ×0.50 是被审出来的：成品纸面 std 只有 1.8，200% 放大下纸是平的、没有纤维。
# 提到 ×0.85（仍是 45px 高通，不会把"云斑"带回来），让纸在近看时有颗粒。
fine = np.clip(p - np.asarray(pi.filter(ImageFilter.GaussianBlur(45)), dtype=np.float32), -7, 12)
d = fine * 0.85
r = np.clip(240 + d, 0, 255)
g = np.clip(231 + d, 0, 255)
b = np.clip(214 + d, 0, 255)
Image.fromarray(np.dstack([r, g, b]).astype(np.uint8), 'RGB').save(
    'assets/paper.jpg', quality=88, optimize=True)
print('[paper] 纤维起伏 std=%.1f（高通后）-> 暖调 700x820' % fine.std())

# ---------- 4. 纸的手工毛边（deckle）----------
# 纸要出血到屏幕边缘，底边就不能是笔直的切线，否则整块纸会被读成"卡片"
import random
import urllib.parse

random.seed(20261010)
W, H, N = 390, 566, 72
# 72 段（8px 一段的锯齿会成尖角，真手工毛边更细更绵）；振幅收小，另加 10% 概率的小缺口
y, ys = 558, []
for _ in range(N + 1):
    y = max(552, min(564, y + random.randint(-3, 3)))
    if random.random() < 0.10:
        y = max(549, y - random.randint(3, 6))
    ys.append(y)
step = W / float(N)
pts = ["M0 0", "H%d" % W, "V%d" % ys[0]]
for i, yy in enumerate(ys[1:], 1):
    pts.append("L%d %d" % (round(W - i * step), yy))
pts += ["L0 %d" % ys[-1], "Z"]
deckle = "data:image/svg+xml," + urllib.parse.quote(
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 390 566' preserveAspectRatio='none'>"
    "<path d='" + " ".join(pts) + "' fill='#fff'/></svg>", safe="")

# ---------- 5. 内联进 HTML ----------
html = open(SRC_HTML, encoding='utf-8').read()
total = 0
for name, mime in (('ink-blot.png', 'image/png'),
                   ('ink-wave.png', 'image/png'),
                   ('film-grain-dark.png', 'image/png'),
                   ('paper.jpg', 'image/jpeg')):
    raw = open('assets/' + name, 'rb').read()
    uri = 'data:%s;base64,%s' % (mime, base64.b64encode(raw).decode())
    total += len(uri)
    print('   %-18s %6.1f KB -> uri %6.1f KB' % (name, len(raw) / 1024, len(uri) / 1024))
    html = html.replace('assets/' + name, uri)
html = html.replace('__DECKLE__', deckle)
total += len(deckle)
assert '__DECKLE__' not in html, 'deckle 占位符未替换'
open(OUT_HTML, 'w', encoding='utf-8').write(html)
print('   %-18s %6d 字符 -> 内联' % ('deckle(svg)', len(deckle)))
print('内联总占用 %.1f KB   -> %s 共 %.1f KB' % (total / 1024, OUT_HTML, len(html.encode()) / 1024))
